getwd()
traps.data2022 <- read.csv("2022.P11.csv")




