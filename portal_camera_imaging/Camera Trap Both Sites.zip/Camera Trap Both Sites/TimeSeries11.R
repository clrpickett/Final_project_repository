####Time Series by Species 
time.series11<-read.csv("TimeSeries11.csv")
time.series11
ggplot(time.series11, aes(x=Month,y=Frequency,group=Species,col=Species))+geom_line()+
  xlab("Month")+ylab("Species Abudance")+ggtitle("2019-2022 Species Abundance Plot 11")+
  theme_classic()+theme(plot.title = element_text(hjust = 0.5))

###Now one plot for each species 

ggplot(time.series11, aes(x=Month,y=Frequency))+geom_line(aes(group=1))+
  xlab("Month")+ylab("Species Abudance")+ggtitle("2019-2022 Species Abundance Plot 11")+
 theme(plot.title = element_text(hjust = 0.5))+facet_wrap(~Species)

###Now moving on to animal group 
group11<-read.csv("Plot11Group1.csv")
group11
install.packages("ggplot2")
require(ggplot2)
library(ggplot2)    #####you HAVE to introduce ggplot into R each time
####Time series by group 
ggplot(group11, aes(x=Month,y=Frequency))+geom_line(aes(group=1))+
  xlab("Month")+ylab("Group Abundance")+ggtitle("2019-2022 Animal Group Abundance Plot 11")+
  theme(plot.title = element_text(hjust = 0.5))+facet_wrap(~Group)
###Time series all together 
ggplot(group11, aes(x=Month,y=Frequency,group=Group,col=Group))+geom_line()+
  xlab("Month")+ylab("Group Abudance")+ggtitle("2019-2022 Group Abundance Plot 11")+
  theme_classic()+theme(plot.title = element_text(hjust = 0.5))





####Pat's Code NOW



#LOOK AT DATA####
str(Plot11AllYearsAllData_)


#MANIPULATE DATA####
plot11=Plot11AllYearsAllData_%>%
  pivot_longer(names_to="")
summarise(cols=3:14,
          names_to="month")



plot11=read.csv("Plot11AllYearsAllData .csv")

#manipulate data
plot11_long=plot11%>%
  pivot_longer(cols=3:14,
               names_to="month", values_to="frequency")
#create dataframe to get frequency of each sp.at each month across all years
plot11_summary=plot11_long%>%
  filter(!is.na(frequency), !Species=="Canis")%>%
  group_by(Species, month)%>%
  summarise(freq_n=sum(frequency))

#plot
ggplot(plot11_summary, aes(x=factor(month, level=c("January", "February", "March", "April", "May",
                                                   "June", "July", "August", "September", "October",
                                                   "November", "December")), y=freq_n))+ #call the relevant cols;reorder x-axes labels
  geom_col()+ #create bins
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+ #remvoe gridlines
  facet_wrap(~Species)+ #separate plot for each spp.
  ylab("number of observations")+xlab("month") #rename x and y-axes labels

plot11_long=plot11%>%
  pivot_longer(cols=3:14,
               names_to="month", values_to="frequency")%>%
  mutate(taxon=case_when(Species=="Zenaida macroura"~"bird",
                         Species=="Lacertilia"~"reptile",
                         Species=="Aspidoscelis"~"reptile",
                         Species=="Serpentes"~"reptile",
                         Species=="Sparrow"~"bird",
                         Species=="Pituophis catenifer affinis"~"reptile",
                         Species=="Masticophis flagellum"~"reptile",
                         Species=="Callipepla gambelii"~"bird",
                         Species=="Callipepla squamata"~"bird",
                         Species=="Campylorhynchus brunneicapillus"~"bird",
                         Species=="Zonotrichia leucophrys"~"bird",
                         Species=="Lanius ludovicianus"~"bird",
                         Species=="Tayassu tajacu"~"mammal",
                         Species=="Pooecetes gramineus"~"bird",
                         Species=="Passer domesticus"~"bird", 
                         Species=="Canis latrans"~"mammal",
                         Species=="Vulpes macrotis"~"mammal",
                         Species=="Amphispiza bilineata"~"bird",
                         Species=="Eumeces obsoletus"~"reptile",
                         Species=="Aspidoscelis sonorae"~"reptile",
                         Species=="Aspidoscelis burti"~"reptile", 
                         Species=="Aspidoscelis exsanguis"~"reptile",
                         Species=="Chiroptera"~"mammal", 
                         Species=="Anura"~"amphibian", 
                         Species=="Buteo jamaicensis"~"bird"))
plot11_long
plot11_taxa=plot11_long%>%
  filter(!is.na(frequency), !Species=="Canis")%>%
  group_by(Species, month, taxon)%>%
  summarise(freq_n=sum(frequency))

#plot
ggplot(plot11_taxa, aes(x=factor(month, level=c("January", "February", "March", "April", "May",
                                                "June", "July", "August", "September", "October",
                                                "November", "December")), y=freq_n))+ #call the relevant cols;reorder x-axes labels
  geom_col()+ #create bins
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+ #remvoe gridlines
  facet_wrap(~taxon)+ #separate plot for each spp.
  ylab("number of observations")+xlab("month") #rename x and y-axes labels



###Now to group by trophic level 
plot11_long2=plot11%>%
  pivot_longer(cols=3:14,
               names_to="month", values_to="frequency")%>%
  mutate(taxon=case_when(Species=="Zenaida macroura"~"primary consumer",
                         Species=="Lacertilia"~"secondary consumer",
                         Species=="Aspidoscelis"~"secondary consumer",
                         Species=="Serpentes"~"secondary consumer",
                         Species=="Sparrow"~"secondary consumer",
                         Species=="Pituophis catenifer affinis"~"tertiary consumer",
                         Species=="Masticophis flagellum"~"tertiary consumer",
                         Species=="Callipepla gambelii"~"secondary consumer",
                         Species=="Callipepla squamata"~"secondary consumer",
                         Species=="Campylorhynchus brunneicapillus"~"secondary consumer",
                         Species=="Zonotrichia leucophrys"~"secondary consumer",
                         Species=="Lanius ludovicianus"~"tertiary consumer",
                         Species=="Tayassu tajacu"~"secondary consumer",
                         Species=="Pooecetes gramineus"~"secondary consumer",
                         Species=="Passer domesticus"~"secondary consumer", 
                         Species=="Canis latrans"~"tertiary consumer",
                         Species=="Vulpes macrotis"~"tertiary consumer",
                         Species=="Amphispiza bilineata"~"secondary consumer",
                         Species=="Eumeces obsoletus"~"secondary consumer",
                         Species=="Aspidoscelis sonorae"~"secondary consumer",
                         Species=="Aspidoscelis burti"~"secondary consumer", 
                         Species=="Aspidoscelis exsanguis"~"secondary consumer",
                         Species=="Chiroptera"~"secondary consumer", 
                         Species=="Anura"~"secondary consumer", 
                         Species=="Buteo jamaicensis"~"tertiary consumer"))
plot11_long2
plot11_taxa2=plot11_long2%>%
  filter(!is.na(frequency), !Species=="Canis")%>%
  group_by(Species, month, taxon)%>%
  summarise(freq_n=sum(frequency))

#plot
ggplot(plot11_taxa2, aes(x=factor(month, level=c("January", "February", "March", "April", "May",
                                                "June", "July", "August", "September", "October",
                                                "November", "December")), y=freq_n))+ #call the relevant cols;reorder x-axes labels
  geom_col()+ #create bins
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
        panel.border = element_blank(), panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+ #remvoe gridlines
  facet_wrap(~taxon)+ #separate plot for each spp.
  ylab("number of observations")+xlab("month") #rename x and y-axes labels


