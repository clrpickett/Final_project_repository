
###creating a library with packages 
install.packages("ggplot2")
install.packages("dplyr")
install.packages("tidyr")
install.packages("reshape2")



#LOAD PACKAGES####
#or type library("package")
require("dplyr")
require("tidyr")
require("reshape2")
require("ggplot2")

#LOOK AT DATA####
str(Plot21AllFiles)


#MANIPULATE DATA####
plot21=Plot21AllFiles%>%
  pivot_longer(names_to="")
  summarise(cols=3:14,
            names_to="month")
  
  
  
  plot21=read.csv("Plot21AllFiles.csv")
  
  #manipulate data
  plot21_long=plot21%>%
    pivot_longer(cols=3:14,
                 names_to="month", values_to="frequency")
  
  #create dataframe to get frequency of each sp.at each month across all years
  plot21_summary=plot21_long%>%
    filter(!is.na(frequency), !Species=="Canis")%>%
    group_by(Species, month)%>%
    summarise(freq_n=sum(frequency))
  
  #plot
  ggplot(plot21_summary, aes(x=factor(month, level=c("January", "February", "March", "April", "May",
                                                     "June", "July", "August", "September", "October",
                                                     "November", "December")), y=freq_n))+ #call the relevant cols;reorder x-axes labels
    geom_col()+ #create bins
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          panel.border = element_blank(), panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+ #remvoe gridlines
    facet_wrap(~Species)+ #separate plot for each spp.
    ylab("frequency of observations")+xlab("month") #rename x and y-axes labels
  
  plot21_long=plot21%>%
    pivot_longer(cols=3:14,
                 names_to="month", values_to="frequency")%>%
    mutate(taxon=case_when(Species=="Zenaida macroura"~"bird",
                           Species=="Lacertilia"~"reptile",
                           Species=="Aspidoscelis"~"reptile",
                           Species=="Serpentes"~"reptile",
                           Species=="Sparrow"~"bird",
                           Species=="Canis"~"mammal", 
                           Species=="Gopherus morafkai"~"reptile",
                           Species=="Callipepla gambelii"~"bird",
                           Species=="Callipepla squamata"~"bird",
                           Species=="Campylorhynchus brunneicapillus"~"bird",
                           Species=="Odocoileus virginianus couesi"~"mammal",
                           Species=="Taxidea taxus"~"mammal",
                           Species=="Tayassu tajacu"~"mammal",
                           Species=="Pooecetes gramineus"~"bird",
                           Species=="Mephitis mephitis"~"mammal",
                           Species=="Canis latrans"~"mammal",
                           Species=="Vulpes macrotis"~"mammal",
                           Species=="Amphispiza bilineata"~"bird",
                           Species=="Lynx rufus"~"mammal",
                           Species=="Crotalus atrox"~"reptile"))
  plot21_long
  plot21_taxa=plot21_long%>%
    filter(!is.na(frequency), !Species=="Canis")%>%
    group_by(Species, month, taxon)%>%
    summarise(freq_n=sum(frequency))
  
  #plot
  ggplot(plot21_taxa, aes(x=factor(month, level=c("January", "February", "March", "April", "May",
                                                  "June", "July", "August", "September", "October",
                                                  "November", "December")), y=freq_n))+ #call the relevant cols;reorder x-axes labels
    geom_col()+ #create bins
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          panel.border = element_blank(), panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+ #remvoe gridlines
    facet_wrap(~taxon)+ #separate plot for each spp.
    ylab("number of observations")+xlab("month") #rename x and y-axes labels
    
  
  
  
  ####Group by trophic level 
  
  plot21_long2=plot21%>%
    pivot_longer(cols=3:14,
                 names_to="month", values_to="frequency")%>%
    mutate(taxon=case_when(Species=="Zenaida macroura"~"primary consumer",
                           Species=="Lacertilia"~"secondary consumer",
                           Species=="Aspidoscelis"~"secondary consumer",
                           Species=="Serpentes"~"secondary consumer",
                           Species=="Sparrow"~"secondary consumer",
                           Species=="Canis"~"tertiary consumer", 
                           Species=="Gopherus morafkai"~"primary consumer",
                           Species=="Callipepla gambelii"~"secondary consumer",
                           Species=="Callipepla squamata"~"secondary consumer",
                           Species=="Campylorhynchus brunneicapillus"~"secondary consumer",
                           Species=="Odocoileus virginianus couesi"~"primary consumer",
                           Species=="Taxidea taxus"~"tertiary consumer",
                           Species=="Tayassu tajacu"~"secondary consumer",
                           Species=="Pooecetes gramineus"~"secondary consumer",
                           Species=="Mephitis mephitis"~"tertiary consumer",
                           Species=="Canis latrans"~"tertiary consumer",
                           Species=="Vulpes macrotis"~"tertiary consumer",
                           Species=="Amphispiza bilineata"~"secondary consumer",
                           Species=="Lynx rufus"~"tertiary consumer",
                           Species=="Crotalus atrox"~"tertiary consumer"))
  plot21_long2
  plot21_taxa2=plot21_long2%>%
    filter(!is.na(frequency), !Species=="Canis")%>%
    group_by(Species, month, taxon)%>%
    summarise(freq_n=sum(frequency))
  
  #plot
  ggplot(plot21_taxa2, aes(x=factor(month, level=c("January", "February", "March", "April", "May",
                                                  "June", "July", "August", "September", "October",
                                                  "November", "December")), y=freq_n))+ #call the relevant cols;reorder x-axes labels
    geom_col()+ #create bins
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          panel.border = element_blank(), panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(), axis.line = element_line(colour = "black"))+ #remvoe gridlines
    facet_wrap(~taxon)+ #separate plot for each spp.
    ylab("number of observations")+xlab("month") #rename x and y-axes labels
  