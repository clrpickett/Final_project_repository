
read.csv("Camera Traps (version 2).csv")
traps.data11 <- read.csv("Camera Traps (version 2).csv")
traps.data11
traps.data2<-traps.data11[c(-1,-2)]
traps.data2
chisq.test(traps.data2, simulate.p.value=TRUE)

