getwd()
species.series21sp <-read.csv("Plot21TimeSeries.csv")
species.series21sp
library(ggplot2)

###Overall Species Sightings 

ggplot(species.series21sp, aes(x=Month,y=Frequency,group=Species,col=Species))+geom_line()+
  xlab("Month")+ylab("Species Observations")+ggtitle("2021-2023 Species Observations Plot 21")+
  theme_classic()+theme(plot.title = element_text(hjust = 0.5))


ggplot(species.series21sp, aes(x=Month,y=Frequency))+geom_line(aes(group=1))+
  xlab("Month")+ylab("Species Observations")+ggtitle("2021-2023 Species Observations Plot 21")+
  theme(plot.title = element_text(hjust = 0.5))+facet_wrap(~Species)

###Now on to groups 
group21<-read.csv("Plot21Groups.csv")

ggplot(group21, aes(x=Month,y=Frequency))+geom_line(aes(group=1))+
  xlab("Month")+ylab("Group Frequency")+ggtitle("2021-2023 Animal Group Observation Frequencies Plot 21")+
  theme(plot.title = element_text(hjust = 0.5))+facet_wrap(~Group)

###Time series all together 
ggplot(group21, aes(x=Month,y=Frequency,group=Group,col=Group))+geom_line()+
  xlab("Month")+ylab("Group Frequency")+ggtitle("2021-2023 Animal Group Observation Frequencies Plot 21")+
  theme_classic()+theme(plot.title = element_text(hjust = 0.5))




